@extends('frontend.layouts.app')

@section('styles')
    <link rel="stylesheet" href="{{ asset('public/frontend/templates/css/prism.min.css') }}">
@endsection

@section('content')
    <!-- Hero section -->
    <div class="standards-hero-section">
        <div class="px-240">
            <div class="d-flex flex-column align-items-start">
                <nav class="customize-bcrm">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">{{ __('Home') }}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{ __('Developer') }}</li>
                    </ol>
                </nav>
                <div class="btn-section">
                    <button class="btn btn-dark btn-lg">{{ __('Developer') }}</button>
                </div>
                <div class="merchant-text">
                    <p>{{ __('With Pay Money Standard and Express, you can easily and safely receive online payments from your customer.') }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Merchant tab -->
    @include('frontend.pages.merchant_tab')


    <!--Paymoney code-snippet-section-->
    <div class="px-240 code-snippet-section">
        <div class="snippet-module">
            <div class="snippet-text">
                <div class="standard-title-text mb-28">
                    <h3>{{ __(':x Merchant Payment Rest API Documentation', ['x' => settings('name')]) }}</h3>
                </div>
                <span>{{ __('Description') }}</span>
                <p>{{ __('This document is a guide on how to integrate Merchant Payment with Rest API.') }} <br> {{ __('The API is a restful web service, which accept form data as input. All methods are implemented as POST.') }} <br> {{ __('Before anything to do the user (who is paying to the merchant) must be logged in to get the authorization token.') }}</p>
            </div>
        </div>
        <div class="snippet-module">
            <div class="snippet-text">
                <span>{{ __('LOGIN VIA API') }}</span>
                <p>
                    <b>URL:</b> {{ url('/api/login') }}
                    <br>
                    <b>Method Type:</b> POST
                    <br>
                    <b>Sample Request:</b> BODY PARAMETER (form-data)
                </p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"email":"david.luca@gmail.com","password":"123456"} 
                        </code>
                    </pre>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <th>{{ __('Parameter') }}</th>
                        <th>{{ __('Description') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th>{{ __('Type') }}</th>
                        <th>{{ __('Sample') }}</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{{ __('email') }}</td>
                            <td>{{ __('Must be email') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>david.luca@gmail.com </td>
                        </tr>
                        <tr>
                            <td>{{ __('password') }}</td>
                            <td>{{ __('User Password') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>123456</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="snippet-text">
                <span>{{ __('SAMPLE RESPONSE') }}</span>
                <p>{{ __('Login Successful') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"response":{"user_id":4,"first_name":"David","last_name":"Luca","email":"david.luca@gmail.com","formattedPhone":null,"picture":"","defaultCountry":"US","TOKEN":"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6Ijg0OGU2NjhhZDdjMWRmYzhjODA1NGE0NjY5ZTM0OGYyND","STATUS":200,"USER-STATUS":"ACTIVE"}}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>{{ __('Login Error') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"response":{"status":401,"message":"Invalid email & credentials"}}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>{{ __('N.B: You have to use this genereted TOKEN on all other steps as Authorization-token in the header section.') }}</p>
            </div>
        </div>
        <div class="snippet-module">
            <div class="snippet-text">
                <span>{{ __('End Point 1: Merchant Verify') }}</span>
                <p>
                    <b>{{ __('URL') }}:</b> {{ url('/api/merchant/verify') }} <br>
                    <b>{{ __('Method') }}:</b> POST <br>
                    <b>{{ __('Description') }}:</b> {{ __('Go to merchant account') }}, {{ url('/merchants') }} {{ __('Click gear icon of
                    approved express merchant.') }}<br>
                    {{ __('From the modal copy Client id, Client Secret. This method is used to
                    generate an access token.') }}<br>
                    <b><u>{{ __('N.B') }}:</b></u> {{ __('If the merchant is approved by the admin, only then the gear icon will be available for that merchant. Authorization-token must be sent as header.') }}
                </p>
            </div>
            <div class="snippet-text">
                <span>{{ __('SAMPLE REQUEST ') }}</span>
                <p>BODY PARAMETER (form-data)</p>
            </div>
            <div class="language-container">
                <div class="snippet line-numbers">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {" client_id":" yMKqAvC2dILUyhwdIbryh4rsl784kF"," client_secret":" ZubitDCg2QyxuoSu0l6pJkNB5lOrcl1Ivy0qZlhlu8QhWHDYOelkVSNC8B0ybunOb3i832W3FC2SUuXw04Rj8kRHduMx7pdD4a48"}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>HEADER PARAMETER </p>
            </div>
            <div class="language-container">
                <div class="snippet line-numbers">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {“ Authorization-token”:” eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIzIiwianRpIjoiNTFiMTU5N2EyYjI4NDMxMzFiZWM0MTdlZGI4NmExOTcyNGZhYWVlZWMzZGNjMjNkMzRlOTE2YjVkYzJlM2M0NjEwODJkOGNlNTdlZGNkNmYiLCJpYXQiOjE2MzYxNzk5MjgsIm5iZiI6MTYzNjE3OTkyOCwiZXhwIjoxNjY3NzE1OTI4LCJzdWIiOiI0Iiwic2NvcGVzIjpbXX0...”} 
                        </code>
                    </pre>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <th>{{ __('Parameter') }}</th>
                        <th>{{ __('Description') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th>{{ __('Type') }}</th>
                        <th>{{ __('Sample') }}</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{{ __('client_id') }}</td>
                            <td>{{ __('Merchant Client ID') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>yMKqAvC2dILUyhwdIbryh4rsl784kF </td>
                        </tr>
                        <tr>
                            <td>{{ __('client_secret') }}</td>
                            <td>{{ __('Merchant Secret') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>ZubitDCg2QyxuoSu0l6pJkNB5lOrcl1Ivy0qZlhlu8QhWHDYOe...</td>
                        </tr>
                        <tr>
                            <td>{{ __('Authorization-token') }}</td>
                            <td>{{ __('Must be given in header, token that is generated after login response for user.') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIzIiw...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="snippet-text">
                <span>{{ __('SAMPLE RESPONSE') }}</span>
                <p>{{ __('Merchant exists') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"success":{"response":{"status":"success","message":"Client Verified","data":{"access_token":"PIdb49a6imxSecjkr2tn21YSPn"}},"status":200}}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>{{ __('Merchant does not exist') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"success":{"status":407,"message":"Can not verify the client. Please check client Id and Client Secret!"}}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>{{ __('N.B: You have to use this genereted access_token on next step as AUTHORIZATION') }}</p>
            </div>
        </div>
		<div class="snippet-module">
            <div class="snippet-text">
                <span>{{ __('End Point - 2. Transaction Info') }}</span>
                <p>
                    <b>{{ __('URL') }}:</b> {{ url('/api/merchant/transaction-info') }} <br>
                    <b>{{ __('Method') }}:</b> POST <br>
                    <b>{{ __('Description') }}:</b> {{ __('We use this endpoint to store the payment information. Get the access token which is generated by verifying merchant in previous step. Use') }} “Authorization-token” {{ __('and') }} “Authorization” {{ __('as headers.') }} “Authorization-token” {{ __('is generated from') }} <code>{{ url('/api/login') }}</code><br>
                    <b><u>{{ __('N.B') }}:</b></u> {{ __('You will need to set the Authorization: Bearer followed by the token value. Add successUrl and cancelUrl as you need. For currency code use ISO format.') }}
                </p>
            </div>
            <div class="snippet-text">
                <span>{{ __('SAMPLE REQUEST ') }}</span>
                <p>BODY PARAMETER (form-data)</p>
            </div>
            <div class="language-container">
                <div class="snippet line-numbers">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"payer":"David Luca","amount":"10","currency":"USD","email":"david.luca@gmail.com","successUrl":"{{ url('/dashboard') }}","cancelUrl":"{{ url('/') }}"}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>HEADER PARAMETER </p>
            </div>
            <div class="language-container">
                <div class="snippet line-numbers">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {" Authorization-token ":"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6Ijg0OGU2NjhhZDdjMWRmYzhjODA1NGE0NjY5ZTM0OGYyND..."," Authorization ":"Bearer 5UTduND48M4qrbSJ9i3CVuQ2cE "}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <th>{{ __('Parameter') }}</th>
                        <th>{{ __('Description') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th>{{ __('Type') }}</th>
                        <th>{{ __('Sample') }}</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{{ __('payer') }}</td>
                            <td>{{ __('Who will receive the payment') }} </td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>David Luca </td>

                        </tr>
                        <tr>
                            <td>{{ __('amount') }}</td>
                            <td>{{ __('The amount User have to pay.') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('Double') }}</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>{{ __('currency') }}</td>
                            <td>{{ __('The payment occur on which currency, it should be ISO code.') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>USD</td>
                        </tr>
                        <tr>
                            <td>{{ __('Email') }}</td>
                            <td>{{ __('Email of the user who is making the payment') }}</td>
                            <td>{{ __('Optional') }}</td>
                            <td>{{ __('Email') }}</td>
                            <td>david.luca@gmail.com</td>
                        </tr>
                        <tr>
                            <td>{{ __('successUrl') }}</td>
                            <td>{{ __('Application dashboard url') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>{{ url('/dashboard') }}</td>
                        </tr>
                        <tr>
                            <td>{{ __('cancelUrl') }}</td>
                            <td>{{ __('Application root url') }} </td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>{{ url('/') }}</td>
                        </tr>
                        <tr>
                            <td>{{ __('Authorization-token') }} </td>
                            <td>{{ __('Must be given in header, token that is generated after login response for user.') }} </td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td> eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQi...</td>
                        </tr>
                        <tr>
                            <td>{{ __('Authorization') }}</td>
                            <td>{{ __('Must be given in header, collect it from merchant verify') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td> Bearer PIdb49a6imxSecjkr2tn21YSPn</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="snippet-text">
                <span>{{ __('SAMPLE RESPONSE') }}</span>
                <p>{{ __('Success') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"success":{"status":"success","grandId":78509912,"token":"VPJSyzRvTgzWGll3xjTI","messag
                    e":"","data":{"approvedUrl":"{{ url('/merchant/payment?grant_id=78509912&token=VPJSyzRvTgzWGll3xjTI') }}"}}}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>{{ __('Invalid Currency') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"success":{"status":"error","message":"Currency GBP is not supported by this merchant!","data":[]}}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>{{ __('Amount Zero') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"success":{"status":"error","message":"Amount cannot be 0 or less than 0.","data":[]}}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>{{ __('N.B: After performing the above step, you will get grant_id and token. These value will be needed for the next step.') }}</p>
            </div>
        </div>
		<div class="snippet-module">
            <div class="snippet-text">
                <span>{{ __('End Point - 3. PAYMENT') }}</span>
                <p>
                    <b>{{ __('URL') }}:</b> {{ url('/api/merchant/payment/') }} <br>
                    <b>{{ __('Method') }}:</b> POST <br>
                    <b>{{ __('Description') }}:</b> {{ __('In this endpoint payment will success, Checks all kinds of input validation and redirected to payment page (if user not logged in then user have to login) if all validation passed. User have to decide to cancel or accept the payment. User grant_id & token as body parameter which is generated in previous step.') }}
                </p>
            </div>
            <div class="snippet-text">
                <span>{{ __('SAMPLE REQUEST ') }}</span>
                <p>BODY PARAMETER (form-data)</p>
            </div>
            <div class="language-container">
                <div class="snippet line-numbers">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"grant_id":"55890128","token":" OfCErZrxuiDqxTjscQon "}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>HEADER PARAMETER </p>
            </div>
            <div class="language-container">
                <div class="snippet line-numbers">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {“ Authorization-token”:” eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6Ijg0OGU2NjhhZDdjMWRmYzhjODA1NGE0NjY5ZTM0OGYyND...”}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <th>{{ __('Parameter') }}</th>
                        <th>{{ __('Description') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th>{{ __('Type') }}</th>
                        <th>{{ __('Sample') }}</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>grant_id</td>
                            <td>{{ __('Get from endpoint-2') }} </td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('Double') }}</td>
                            <td>78509912 </td>
                        </tr>

                        <tr>
                            <td>token</td>
                            <td>{{ __('Get from endpoint-2') }} </td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>VPJSyzRvTgzWGll3xjTI </td>
                        </tr>

                        <tr>
                            <td>{{ __('Authorization-token') }}</td>
                            <td>{{ __('Must be given in header, token that is generate after login response for user.') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aS...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="snippet-text">
                <span>{{ __('SAMPLE RESPONSE') }}</span>
                <p>{{ __('Payment Success') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"success": {"status": 200,"message": "Success","successUrl": "{{ url('/?eyJzdGF0dXMiOjIwMCwidHJhbnNhY3Rpb25faWQiOiJFQjlCRUM0MUYyMDRCIiwibWVyY2hhbnQiOiJBc2hyYWZ1bCBSYXNlbCIsImN1cnJlbmN5IjoiVVNEIiwiZmVlIjowLjE0OTk5OTk5OTk5OTk5OTk5NDQ0ODg4NDg3Njg3NDIxNzI5Nzg4MTg0MTY1OTU0NTg5ODQzNzUsImFtb3VudCI6OS44NDk5OTk5OTk5OTk5OTk2NDQ3Mjg2MzIxMTk5NDk5MDcwNjQ0Mzc4NjYyMTA5Mzc1LCJ0b3RhbCI6IjEwLjAwMDAwMDAwIn0="')}}}}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>{{ __('Merchant & User same') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"success":{"status":801,"message":"Merchant cannot make payment to himself!"}}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>{{ __('Grant Id or Token Mismatch') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"success":{"status":401,"message":"Grant Id or Token does not Match!"}}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>{{ __('Insufficient Balance') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"success":{"status":401,"message":"User doesn't have sufficient balance!"}}
                        </code>
                    </pre>
                </div>
            </div>
        </div>
        <div class="snippet-module mb-0">
            <div class="snippet-text">
                <span>{{ __("End Point 4: PAYMENT CANCEL") }}</span>
                <p>
                    <b>{{ __('URL') }}:</b> {{ url('/api/merchant/payment/cancel') }} <br>
                    <b>{{ __('Method') }}:</b> POST <br>
                    <b>{{ __('Description') }}:</b> {{ __('To cancel the payment this url is used. To cancel a payment, after endpoint #2 make a request to endpoint #4. Provide “Authorization-token” from') }} {{ url('/api/login') }} {{ __('and token from endpoint #2.') }}
                </p>
            </div>
            <div class="snippet-text">
                <span>{{ __('SAMPLE REQUEST ') }}</span>
                <p>BODY PARAMETER (form-data)</p>
            </div>
            <div class="language-container">
                <div class="snippet line-numbers">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"grant_id":"55890128","token":" OfCErZrxuiDqxTjscQon "}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="snippet-text">
                <p>HEADER PARAMETER </p>
            </div>
            <div class="language-container">
                <div class="snippet line-numbers">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {“ Authorization-token”:” eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6Ijg0OGU2NjhhZDdjMWRmYzhjODA1NGE0NjY5ZTM0OGYyND...”}
                        </code>
                    </pre>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <th>{{ __('Parameter') }}</th>
                        <th>{{ __('Description') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th>{{ __('Type') }}</th>
                        <th>{{ __('Sample') }}</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>grant_id</td>
                            <td>{{ __('Get from endpoint-2') }} </td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('Double') }}</td>
                            <td>78509912 </td>
                        </tr>

                        <tr>
                            <td>token</td>
                            <td>{{ __('Get from endpoint-2') }} </td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>VPJSyzRvTgzWGll3xjTI</td>
                        </tr>

                        <tr>
                            <td>{{ __('Authorization-token') }}</td>
                            <td>{{ __('Must be given in header, token that is generated after login response for user.') }}</td>
                            <td>{{ __('Required') }}</td>
                            <td>{{ __('String') }}</td>
                            <td>eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiO...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="snippet-text">
                <span>{{ __('SAMPLE RESPONSE') }}</span>
                <p>{{ __('Payment Cancelled') }}</p>
            </div>
            <div class="language-container">
                <div class="snippet">
                    <pre class="language-php thin-scrollbar">
                        <code>
                            {"success": {"status": 200, "message": "Payment cancelled successfully", "cancelUrl": "{{ url('/dashboard') }}"}}
                        </code>
                    </pre>
                </div>
            </div>
        </div>
   </div> 
@endsection

@section('js')
    <script src="{{ asset('public/frontend/templates/js/prism.min.js') }}"></script>
@endsection
