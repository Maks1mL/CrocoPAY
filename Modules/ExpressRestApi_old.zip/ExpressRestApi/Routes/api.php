<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\ExpressRestApi\Http\Controllers\Api\ExpressRestApiController;

Route::namespace('Api')->group(function () {
    Route::post('/merchant/verify', [ExpressRestApiController::class, 'verifyClient']);
    Route::post('/merchant/transaction-info', [ExpressRestApiController::class, 'storeTransactionInfo']);

    Route::middleware('check-authorization-token')->group(function () {
        Route::post('/merchant/payment', [ExpressRestApiController::class, 'generatedUrl'])->name('payment');
        Route::post('/merchant/payment/cancel', [ExpressRestApiController::class, 'cancelPayment'])->name('cancel-payment');
    });
});
