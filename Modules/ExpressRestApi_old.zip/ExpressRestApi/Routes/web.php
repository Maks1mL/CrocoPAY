<?php

use Illuminate\Support\Facades\Route;

Route::prefix('expressrestapi')->group(function() {
    Route::get('/', 'ExpressRestApiController@index');
});
