<?php

return [
    'name' => 'ExpressRestApi',
    'item_id' => 'rptsepexies',
    'supported_versions' => "4.0.0"
];
